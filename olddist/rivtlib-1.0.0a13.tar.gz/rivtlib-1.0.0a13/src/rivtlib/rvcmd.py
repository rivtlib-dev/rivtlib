# python #!
import csv
import sys
import textwrap
from datetime import datetime
from io import StringIO
from pathlib import Path

import numpy as np
import pandas as pd
import sympy as sp
import tabulate
from fastcore.utils import store_attr
from IPython.display import display as _display
from PIL import Image
from sympy.abc import _clash2

from rivtlib.rvunits import *  # noqa: F403
from rivtlib.unum.core import Unum

tabulate.PRESERVE_WHITESPACE = True


class Cmd:
    """reads, writes and formats files

    Methods:

     API        Command                                                  File Types
    ---------  ------------------------------------------------------- ---------------------
    rv.R        | MARKUP | relative path | type
    rv.V,I      | IMAGE | relative path |  scale, caption, num;non        *.png, .jpg*
    rv.V,I      | IMAGE2 | relative path | s1, s2, c1, c2, n1, n2         *.png, jpg*
    rv.V,I      | TABLE | relative path | width, l;c;r, title, num;non    *csv, txt, xlsx*
    rv.V        | PYTHON | relative path | *rivt*; nmspace                *py*
    rv.V        | VALTABLE | relative path | width, title, num;non        *csv, txt, xlsx*
    rv.V        a ==: 1*IN  | unit1, unit2, decimal | ref                 define value
    rv.V        b <=: a + 3*FT | unit1, unit2, decimal | ref              assign value
    rv.V        c :=: func1(x,y) | unit1, unit2, decimal | ref            function value
    rv.V        b < a | unit, decimal, true text, false text | ref        compare value
    rv.T        | SHELL | relative path | os, *wait;nowait*               *.sh*
    rv.D        | ATTACHPDF
    rv.D        | PUBLISH
    """

    def __init__(self, stS, fD, lD, rivtD, rivL, parL, vardescD):
        """command object

        Args:
            fD (dict): folders
            lD (dict): labels
            rivtD (dict): values
            rivL (list): values for export
            parL ( list): parameter list

        Vars:
            uS (str): utf string
            rS (str): rst string
            tS (str): text string
        """
        # region
        store_attr()
        # unicode switch
        sp.init_printing(use_unicode=True)
        # if stS == "V":
        #     sp.init_printing(use_unicode=False)
        # else:
        #     sp.init_printing(use_unicode=True)

        self.fileS = parL[1].strip()
        self.file2L = parL[1].split(",")
        self.parS = parL[2].strip()
        self.insP = Path(fD["reptP"], self.fileS)
        self.inspS = str(self.insP.as_posix())
        self.uS = ""
        self.rS = ""
        self.tS = ""
        self.lS = ""
        self.wI = self.lD["widthI"]
        self.rivtD = rivtD
        # endregion

    def cmdx(self, cmdS):
        """call command

        Args:
            cmdS (str): command keyword

        Returns:
            uS, rS, tS, lS, fD, lD, rivtD, rivL
        """
        method = getattr(self, cmdS)
        method()

        return self.mD

    def vdefine(self, deqS):
        """define value ==:

            a ==: .5 * 2*IN | unit1, unit2, decimal | ref

            Collects successive rows until hitting a blank line

            Table is written to rv_stor (see rvparse module)

        Returns:
            self.mD, tbL
        """
        # region
        tbL = []
        vaL = deqS.split("|")
        eqS = vaL[0].strip()
        eqS = eqS.replace(" ==: ", " = ")
        varS = eqS.split("=")[0].strip()
        unitL = vaL[1].split(",")
        unit1S, unit2S, dec1S = (
            unitL[0].strip(),
            unitL[1].strip(),
            unitL[2].strip(),
        )
        if unit1S == "--":
            unit1S == "m/m"
        if unit2S == "--":
            unit1S == "m/m"
        # rivt store
        descripS = vaL[2].strip()
        exvS = ",".join((eqS, unit1S, unit2S, dec1S, descripS))
        self.vardescD[varS] = descripS
        self.rivL.append(exvS)
        try:
            exec(eqS, globals(), self.rivtD)
        except ValueError as ve:
            print(f"A ValueError occurred: {ve}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
        decS = "%." + dec1S + "f"
        Unum.set_format(value_format=decS, auto_norm=False, unitless="")
        valU = eval(varS, globals(), self.rivtD)
        if type(valU) is Unum:
            val2S = str(valU.cast_unit(eval(unit2S)))
            val1U = valU.cast_unit(eval(unit1S))
            if val1U.number() == 1.0:
                val1S = str((1 + 10**-10) * val1U)
            else:
                val1S = str(valU.cast_unit(eval(unit1S)))
        else:
            val1S = str(valU)
            val2S = str(valU)
        self.rivtD[varS] = valU  # add to rivt dictionary
        tbL = [varS, val1S, val2S, descripS]  # append row

        return tbL, self.rivtD, self.rivL, self.vardescD
        # endregion

    def vassign(self, aeqS):
        """assign value <=:

            a <=: b + 2 | unit1, unit2, decimal | ref

        Returns:
            uS, rS, tS, fD, lD, rivtD, rivL
        """
        # region
        self.enumI = int(self.lD["equI"])
        self.enumI += 1
        self.lD["equI"] = self.enumI
        self.enumS = str(self.enumI)
        lpL = aeqS.split("|")
        eqS = lpL[0]
        eqS = eqS.replace(" <=: ", " = ").strip()
        unit1S, unit2S, dec1S = lpL[1].split(",")
        unit1S, unit2S, dec1S = unit1S.strip(), unit2S.strip(), dec1S.strip()
        refS = lpL[2].strip()
        decS = "%." + dec1S + "f"
        Unum.set_format(value_format=decS, auto_norm=True, unitless="")
        # print(dir(Unum.set_format))
        spL = eqS.split("=")  # ============== symbolic equation
        spS = "Eq(" + spL[0] + ",(" + spL[1] + "))"
        eq1S = sp.pretty(sp.sympify(spS, _clash2, evaluate=False))
        self.vardescD[spL[0].strip()] = refS
        # text
        eqxS = textwrap.indent(eq1S, chr(9474) + "     ")
        toptS = chr(9484) + "  Eq-" + self.enumS + " | " + refS + "\n"
        eqtS = toptS + chr(9474) + "\n" + eqxS + "\n" + chr(9492) + "\n"
        # rest
        eq1S = textwrap.indent(eq1S, "           ")
        erS = "\n\n**Eq. " + self.enumS + ":**  " + refS + "\n"
        if unit1S != "--":  # =================== rivtD
            exec(eqS, globals(), self.rivtD)
        else:
            unit1S = unit2S = "m/m"
            cmdS = spL[0] + " = " + spL[1]
            exec(cmdS, globals(), self.rivtD)
        valU = eval(spL[0], globals(), self.rivtD)
        self.rivtD[spL[0]] = valU
        val1U = valU.cast_unit(eval(unit1S))
        val2U = valU.cast_unit(eval(unit2S))
        eq2S = sp.pretty(sp.sympify(spL[0], _clash2, evaluate=False))  # results
        tbl1L = []  # ============ values table
        tbl2L = []
        hdr2L = []
        symeqO = sp.sympify(spL[1], _clash2, evaluate=False)
        symaO = symeqO.atoms(sp.Symbol)
        for vS in symaO:
            vS = sp.pretty(sp.sympify(vS, _clash2, evaluate=False))
            hdr2L.append(str(vS))
        for aO in symaO:
            a1U = eval(str(aO), globals(), self.rivtD)
            tbl2L.append(str(a1U))
        dL = []
        for aO in symaO:
            dL.append(self.vardescD[str(aO)])
        tblL = self.wrap_pad(dL)
        tbl1L = list(zip(*tblL))
        lnS = chr(8212) * 5
        lnL = (lnS,) * len(tbl1L[0])
        tbl1L.insert(0, lnL)
        tbl2L = [tbl2L]
        tbl3L = tbl2L + tbl1L
        tblfmt = "rst"
        sys.stdout.flush()
        old_stdout = sys.stdout
        output = StringIO()
        output.write(
            tabulate.tabulate(
                tbl3L,
                tablefmt=tblfmt,
                headers=hdr2L,
                showindex=False,
                colglobalalign="left",
            )
        )
        outputL = output.getvalue().split("\n")[1:]
        outputS = "\n".join(outputL).replace("=", chr(8212))
        eqrS = (
            "\n|\n"
            + erS
            + "\n.. code-block:: text \n\n"
            + eq1S
            + "\n\n           "
            + f"{eq2S} = {val1U}     [{eq2S}] = {val2U}   | {refS.strip()}\n\n"
            + textwrap.indent(outputS, "           ")
        )
        ureS = f"{eq2S} = {val1U}    [{eq2S}] = {val2U}  | {refS.strip()}"
        uS = tS = "\n" + eqtS + "\n" + ureS + "\n\n" + output.getvalue()
        rS = "\n" + eqrS + "\n\n"
        lS = ""
        sys.stdout = old_stdout
        sys.stdout.flush()
        # rivL append - for export
        ex2S = spL[0].strip() + " = " + str(val1U)
        exvS = ",".join((ex2S, unit1S, unit2S, dec1S, refS.strip()))
        self.rivL.append(exvS)
        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lS": lS,
            "lD": self.lD,
            "fD": self.fD,
            "rivtD": self.rivtD,
            "rivL": self.rivL,
        }
        return self.mD, self.vardescD
        # endregion

    def vfunc(self, feqS):
        """format inline function and assign value and var

            equation tag  <=:
            a :=: b + 2 | unit1, unit2, decimal | ref

        Returns:
            uS, r2S, rS, fD, lD, rivtD, rivL
        """
        # region
        self.enumI = int(self.lD["equI"])
        self.enumI += 1
        self.lD["equI"] = self.enumI
        self.enumS = str(self.enumI)
        lpL = feqS.split("|")
        eqS = lpL[0]
        eqS = eqS.replace(" :=: ", " = ").strip()
        unit1S, unit2S, dec1S = lpL[1].split(",")
        unit1S, unit2S, dec1S = unit1S.strip(), unit2S.strip(), dec1S.strip()
        refS = lpL[2].strip()
        decS = "%." + dec1S + "f"
        Unum.set_format(value_format=decS, auto_norm=True, unitless="")
        # print(dir(Unum.set_format))
        spL = eqS.split("=")  # ============== symbolic equation
        spS = "Eq(" + spL[0] + ",(" + spL[1] + "))"
        eq1S = sp.pretty(sp.sympify(spS, _clash2, evaluate=False))
        self.vardescD[spL[0].strip()] = refS
        # text
        eqxS = textwrap.indent(eq1S, chr(9474) + "     ")
        toptS = chr(9484) + "  Eq-" + self.enumS + " | " + refS + "\n"
        eqtS = toptS + chr(9474) + "\n" + eqxS + "\n" + chr(9492) + "\n"
        # rest
        eq1S = textwrap.indent(eq1S, "           ")
        erS = "\n\n**Eq. " + self.enumS + ":**  " + refS + "\n"
        # rst
        self.vardescD[spL[0].strip()] = refS
        if unit1S != "--":  # =================== rivtD
            exec(eqS, globals(), self.rivtD)
        else:
            unit1S = unit2S = "m/m"
            cmdS = spL[0] + " = " + spL[1]
            exec(cmdS, globals(), self.rivtD)
        valU = eval(spL[0], globals(), self.rivtD)
        self.rivtD[spL[0]] = valU
        val1U = valU.cast_unit(eval(unit1S))
        val2U = valU.cast_unit(eval(unit2S))
        eq2S = sp.pretty(sp.sympify(spL[0], _clash2, evaluate=False))  # results
        tbl1L = []  # ============ values table
        tbl2L = []
        hdr2L = []
        symeqO = sp.sympify(spL[1], _clash2, evaluate=False)
        symaO = symeqO.atoms(sp.Symbol)
        for vS in symaO:
            vS = sp.pretty(sp.sympify(vS, _clash2, evaluate=False))
            hdr2L.append(str(vS))
        for aO in symaO:
            a1U = eval(str(aO), globals(), self.rivtD)
            tbl2L.append(str(a1U))
        dL = []
        for aO in symaO:
            dL.append(self.vardescD[str(aO)])
        tblL = self.wrap_pad(dL)
        tbl1L = list(zip(*tblL))
        lnS = chr(8212) * 5
        lnL = (lnS,) * len(tbl1L[0])
        tbl1L.insert(0, lnL)
        tbl2L = [tbl2L]
        tbl3L = tbl2L + tbl1L
        tblfmt = "rst"
        sys.stdout.flush()
        old_stdout = sys.stdout
        output = StringIO()
        output.write(
            tabulate.tabulate(
                tbl3L,
                tablefmt=tblfmt,
                headers=hdr2L,
                showindex=False,
                colglobalalign="left",
            )
        )
        outputL = output.getvalue().split("\n")[1:]
        outputS = "\n".join(outputL).replace("=", chr(8212))
        eqrS = (
            "\n|\n"
            + erS
            + "\n.. code-block:: text \n\n"
            + eq1S
            + "\n\n           "
            + f"{eq2S} = {val1U}     [{eq2S}] = {val2U}   | {refS.strip()}\n\n"
            + textwrap.indent(outputS, "           ")
        )
        ureS = f"{eq2S} = {val1U}   [{eq2S}] = {val2U}  | {refS.strip()}"
        uS = tS = "\n" + eqtS + "\n" + ureS + "\n\n" + output.getvalue()
        rS = "\n" + eqrS + "\n\n"
        lS = ""
        sys.stdout = old_stdout
        sys.stdout.flush()

        # rivL append - for export
        ex2S = spL[0].strip() + " = " + str(val1U)
        exvS = ",".join((ex2S, unit1S, unit2S, dec1S, refS.strip()))
        self.rivL.append(exvS)
        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lS": lS,
            "lD": self.lD,
            "fD": self.fD,
            "rivtD": self.rivtD,
            "rivL": self.rivL,
        }
        return self.mD, self.vardescD
        # endregion

    def vcompare(self, compS, opS):
        """compare values

            comparison operators-a space around the operator is required
            < ,  > ,  != ,  == ,  <= ,  >=

            a < b  | unit, dec, true text, false text | ref

        Returns:
            uS, rS, tS, fD, lD, rivtD, rivL
        """
        # region
        self.enumI = int(self.lD["equI"])
        self.enumI += 1
        self.lD["equI"] = self.enumI
        self.enumS = str(self.enumI)

        lpL = compS.split("|")
        eqS = lpL[0].strip()
        spL = lpL[0].split(opS)
        unitS, decS, trueS, falseS = lpL[1].split(",")
        unitS, decS, trueS, falseS = (
            unitS.strip(),
            decS.strip(),
            trueS.strip(),
            falseS.strip(),
        )
        refS = lpL[2].strip()
        decS = "%." + decS + "f"
        Unum.set_format(value_format=decS, auto_norm=True, unitless="")
        # symbolic equation
        eq1S = sp.pretty(sp.sympify(eqS, _clash2, evaluate=False))
        # text  == symbolic
        eqxS = textwrap.indent(eqS, chr(9474) + "     ")
        toptS = chr(9484) + "  Eq-" + self.enumS + " | " + refS + "\n"
        eqtS = toptS + chr(9474) + "\n" + eqxS + "\n" + chr(9492) + "\n"
        # ====== rivtD
        valU = eval(spL[0], globals(), self.rivtD)
        self.rivtD[spL[0]] = valU
        # print(self.rivtD)
        # compare
        resultB = eval(eqS, {}, self.rivtD)
        if resultB:
            chkS = trueS
        else:
            chkS = falseS
        valU = eval(spL[0], globals(), self.rivtD)
        val1U = valU.cast_unit(eval(unitS))
        valU = eval(spL[1], globals(), self.rivtD)
        val2U = valU.cast_unit(eval(unitS))
        val1L = [val1U, val2U, str(val1U / val2U), chkS, refS]
        tblL = [val1L]
        # ==== tabulate
        term1S = sp.pretty(sp.sympify(spL[0].strip(), _clash2, evaluate=False))
        term2S = sp.pretty(sp.sympify(spL[1].strip(), _clash2, evaluate=False))
        tblfmt = "rst"
        hdrL = [
            "[1] " + term1S,
            "[2] " + term2S,
            "ratio [1]/[2]",
            "check",
            "reference",
        ]
        sys.stdout.flush()
        old_stdout = sys.stdout
        output = StringIO()
        output.write(
            tabulate.tabulate(
                tblL,
                tablefmt=tblfmt,
                headers=hdrL,
                showindex=False,
                colglobalalign="left",
            )
        )
        equL = output.getvalue().split("\n")
        eq3S = output.getvalue()
        sys.stdout = old_stdout
        sys.stdout.flush()

        # text === symbolic and table
        equS = ""
        for ln in equL:
            ln = chr(9646) + "  " + ln
            equS += ln + "\n"
        uS = tS = eqtS + "\n" + equS + "\n"

        # rest  == symbolic and table
        erS = "|\n\n**Eq." + self.enumS + ":** " + refS + "\n"
        outputL = output.getvalue().split("\n")[1:]
        outputS = "\n".join(outputL).replace("=", chr(8212))
        eq3L = outputS.split("\n")
        eq3S = ""
        for ln in eq3L:
            ln = "  " + chr(9646) + " " + ln
            eq3S += ln + "\n"
        rS = (
            "\n|\n"
            + erS
            + "\n.. code-block:: text \n\n  "
            + chr(9646)
            + " "
            + eq1S.strip()
            + "\n  "
            + chr(9646)
            + "\n"
            + eq3S
        )
        lS = " "

        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lS": lS,
            "lD": self.lD,
            "fD": self.fD,
            "rivtD": self.rivtD,
            "rivL": self.rivL,
        }

        return self.mD
        # endregion

    def TEXT(self):
        """_summary_"""
        # fiS = " [file: " + self.fileS + "]" + "\n\n"
        # if typeS == "literal":
        #     uS = "\n" + fiS + "\n" + textS + "\n"
        #     tS = "\n" + textS + "\n"
        #     rS = lS = "\n.. code-block:: text \n\n" + "    " + txtindS + "\n\n"

    def RUNFILE(self):
        """run script and insert

        | RUNFILE | rel. path | text type

            types:
                endnotes
                reST
                html
                LateX

        Returns:
            mD{dict)}
        """

        # region
        typeS = self.parS.strip()
        fiS = " [file: " + self.fileS + "]"
        with open(self.inspS, "r") as f1:
            textS = f1.read()
            # txtindS = textwrap.indent(textS, "    ")
        if typeS == "endnotes":
            endL = textS.split("\n")
            endrS = "\n" + "-" * 80 + "\n\n"
            enduS = fiS + "\n" + "-" * 80 + "\n\n"
            endtS = "\n" + "-" * 80 + "\n\n"
            fnI = 0
            for ln in endL:
                lS = " ".join(ln.strip())
                fnI += 1
                enduS += f"[{str(fnI)}] {lS}\n\n"
                endrS += f".. [{str(fnI)}] {lS}\n\n"
            uS = enduS
            tS = endtS
            rS = lS = endrS

        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lS": lS,
            "lD": self.lD,
            "rivL": self.rivL,
            "rivtD": self.rivtD,
        }

        return self.mD
        # endregion

    def IMAGE(self):
        """insert image

        | IMAGE | rel. path file | caption, scale, num;non
        """
        # region
        lablS = ""
        parL = self.parS.split(",")
        capS = parL[0].strip()
        scS = parL[1].strip()
        figS = parL[2].strip()
        timS = parL[3].strip()
        try:
            img1 = Image.open(self.inspS)
            _display(img1)
        except Exception:
            pass
        if capS == "--":
            capS = ""
        if figS == "num":
            numS = str(self.lD["figI"])
            self.lD["figI"] = int(numS) + 1
            lablS = "**Fig. " + numS + "** - "
            lablxS = "Fig. " + numS + " - "
        else:
            lablS = ""
        lablS = lablS + capS + " "
        bordS = " " * 10 + "-" * 40 + "\n"
        if timS.strip() == "time":
            gettimeS = self.get_image_time(self.inspS)
            if gettimeS is None:
                gettimeS = "no time "
            timeS = " | time: " + gettimeS
        else:
            timeS = " "
        uS = bordS + lablxS + capS + f" [file: {self.fileS}{timeS} ]\n" + bordS
        tS = bordS + lablxS + capS + timeS + "\n" + bordS
        rS = f"""
.. figure:: {self.inspS}
   :width: {scS}%
   :align: center

   {lablS} {timeS}
    

"""
        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lD": self.lD,
            "rivL": self.rivL,
            "rivtD": self.rivtD,
        }
        # endregion

    def IMAGE2(self):
        """insert side by side images

        |IMG2| rel. pth, rel. pth | sf1, sf2, c1, c2 (_[F])
        """
        # region
        # print(f"{parS=}")

        file1S = self.file2L[0].strip()
        file2S = self.file2L[1].strip()
        ins1P = Path(self.fD["reptP"], file1S)
        ins2P = Path(self.fD["reptP"], file2S)
        insp1S = str(ins1P.as_posix())
        insp2S = str(ins2P.as_posix())

        parL = self.parS.split(",")
        cap1S = parL[0].strip()
        cap2S = parL[1].strip()
        scale1S = parL[2].strip()
        scale2S = parL[3].strip()
        fig1S = parL[4].strip()
        fig2S = parL[5].strip()
        try:
            img1 = Image.open(insp1S)
            _display(img1)
            img2 = Image.open(insp2S)
            _display(img2)
        except Exception:
            pass

        if cap1S == "--":
            cap1S = ""
        if cap2S == "--":
            cap2S = ""
        if fig1S == "num":
            num1S = str(self.lD["figI"])
            self.lD["figI"] = int(num1S) + 1
            labl1S = "**Fig. " + num1S + " -** " + cap1S + " "
            labl1xS = "Fig. " + num1S + " - " + cap1S + " "
        else:
            labl1S = ""
        if fig2S == "num":
            num2S = str(self.lD["figI"])
            self.lD["figI"] = int(num2S) + 1
            labl2S = "**Fig. " + num2S + " -** " + cap2S + " "
            labl2xS = "Fig. " + num2S + " - " + cap2S + " "
        else:
            labl2S = ""
        bordS = " " * 10 + "-" * 40 + "\n"
        uS = f"{bordS}{labl1xS} | {labl2xS}\nfiles: {self.fileS} \n{bordS}\n"
        tS = f"{bordS}{labl1xS} | {labl2xS}\n{bordS}\n"
        rS = f"""
.. list-table::
    :widths: {scale1S} {scale2S}
    :header-rows: 0

    * - .. figure:: {insp1S}
            :width: 100%

            {labl1S}
     
      - .. figure:: {insp2S}
            :width: 100%
            
            {labl2S}

                     
"""

        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lD": self.lD,
            "rivL": self.rivL,
            "rivtD": self.rivtD,
        }
        # endregion

    def TABLE(self):
        """insert table

            | TABLE | rel. path | title, width, head;nohead, num;non

        Returns:
            mD{dict)}

        """
        # region
        # print(f"{pthS=}")

        parL = self.parS.split(",")
        titleS = parL[0].strip()
        if titleS == "--":
            titleS = ""
        maxwI = int(parL[1].strip())  # max col. width
        numS = parL[3].strip()
        fiS = " [file: " + self.fileS + "]" + "\n\n"
        if numS == "num":
            tnumI = int(self.lD["tableI"])
            self.lD["tableI"] = tnumI + 1
            utlS = "\nTable " + str(tnumI) + ": " + titleS
            rtlS = "\n**Table " + str(tnumI) + "**: " + titleS
            xtlS = utlS + fiS  # file path text
        else:
            utlS = "\nTable : " + titleS
            rtlS = "\n**Table**: " + titleS
            xtlS = utlS + fiS  # file path - text
        extS = self.insP.suffix  # file extension
        readL = []
        if extS == ".csv":  # read csv file
            with open(self.inspS, "r") as csvfile:
                reader = csv.reader(csvfile)
                for row in reader:
                    # print(f"{row=}")
                    if row and row[0].startswith("#"):
                        continue
                    else:
                        readL.append(row)
        elif extS == "xlsx":  # read xls file
            pDF1 = pd.read_excel(self.pthS, header=None)
            readL = pDF1.values.tolist()
        else:
            pass
        if parL[2].strip() == "head":
            flgS = "firstrow"
        else:
            flgS = "None"
        sys.stdout.flush()
        old_stdout = sys.stdout
        output = StringIO()
        output.write(
            tabulate.tabulate(
                readL,
                tablefmt="rst",
                headers=flgS,
                numalign="decimal",
                maxcolwidths=maxwI,
                colglobalalign="left",
            )
        )
        uS = output.getvalue()
        sys.stdout = old_stdout

        utS = rtS = ltS = ttS = ""
        utS = utlS + "\n\n" + uS + "\n"
        rtS = rtlS + "\n\n" + uS + "\n"
        ltS = ttS = xtlS + "\n\n" + uS + "\n"

        self.mD = {
            "uS": utS,
            "rS": rtS,
            "tS": ttS,
            "lS": ltS,
            "lD": self.lD,
            "fD": self.fD,
            "rivtD": self.rivtD,
            "rivL": self.rivL,
        }
        # endregion

    def VALTABLE(self):
        """read file and insert values

        | VALTABLE | relative path | title, width
        """
        # region
        fuS = self.fileS
        parL = self.parS.split(",")
        titleS = parL[0].strip()
        tnumI = int(self.lD["tableI"])
        self.lD["tableI"] = tnumI + 1
        fillS = str(tnumI)
        titleS = parL[0].strip() + " (" + fuS + ")\n"
        titlerS = parL[0].strip() + " (" + fuS + ")\n\n"
        if titleS[0:2] == "--":
            utlS = xtlS = " (" + fuS + ")\n"
            rtlS = " (" + fuS + ")\n\n"
        else:
            utlS = xtlS = "\nTable " + fillS + ": " + titleS
            rtlS = "|\n\n**Table " + fillS + "**: " + titlerS
        with open(self.insP, "r") as csvfile:
            readL = list(csv.reader(csvfile))
        tbL = []
        for vaL in readL:
            # print(f"{vaL=}")
            if len(vaL) != 5:
                continue
            eqS = vaL[0].strip()
            varS = vaL[0].split("=")[0].strip()
            valS = vaL[0].split("=")[1].strip()
            unit1S, unit2S = vaL[1], vaL[2]
            dec1S, descripS = vaL[3].strip(), vaL[4].strip()
            decS = "%." + dec1S + "f"
            Unum.set_format(value_format=decS, auto_norm=True, unitless="")
            if unit1S != "-":
                if isinstance(eval(valS), list):
                    val1U = np.array(eval(valS)) * eval(unit1S)
                    val2U = [varS.cast_unit(eval(unit2S)) for varS in val1U]
                else:
                    eqS = varS + " = " + valS
                    try:
                        exec(eqS, globals(), self.rivtD)
                    except ValueError as ve:
                        print(f"A ValueError occurred: {ve}")
                    except Exception as e:
                        print(f"An unexpected error occurred: {e}")
                    valU = eval(varS, globals(), self.rivtD)
                    val1U = str(valU.cast_unit(eval(unit1S)))
                    val2U = str(valU.cast_unit(eval(unit2S)))
            else:
                eqS = varS + " = " + valS
                exec(eqS, globals(), self.rivtD)
                valU = eval(varS)
                val1U = str(valU)
                val2U = str(valU)
            tbL.append([varS, val1U, val2U, descripS])
        # print("tbl", tbL)
        for ln in readL:
            symS = str(ln[0].split("=")[0].strip())
            self.vardescD[symS] = ln[4].strip()
        tblfmt = "rst"
        hdrvL = ["variable", "value", "[value]", "description"]
        sys.stdout.flush()
        old_stdout = sys.stdout
        output = StringIO()
        output.write(
            tabulate.tabulate(
                tbL,
                tablefmt=tblfmt,
                headers=hdrvL,
                showindex=False,
                colglobalalign="left",
            )
        )
        outS = output.getvalue()
        sys.stdout = old_stdout
        sys.stdout.flush()
        # pthxS = str(Path(*Path(pthS).parts[-3:]))
        uS = utlS + outS + "\n\n"
        rS = rtlS + outS + "\n\n"
        tS = xtlS + outS + "\n"
        lS = ""

        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lS": lS,
            "lD": self.lD,
            "rivL": self.rivL,
            "rivtD": self.rivtD,
        }

        return self.mD, self.vardescD

        # endregion

    def PYTHON(self):
        """execute Python script

        | PYTHON | rel. path | reference
        """
        # region
        # print(f"{readL=}")
        fuS = self.fileS
        tnumI = int(self.lD["tableI"])
        self.lD["tableI"] = tnumI + 1
        fillS = str(tnumI)
        fileP = Path(self.fD["reptP"], self.fileS)
        with open(fileP, "r") as f10:
            pyscriptS = f10.read()
        exec(pyscriptS, globals(), self.rivtD)
        tbL = []
        funcL = []
        docstrL = []
        docflg = False
        pyscriptL = pyscriptS.split("\n")
        for s in pyscriptL:
            if docflg:
                s = s.replace('"""', "")
                docstrL.append(s)
                docflg = False
            if s[0:3] == "def":
                s = s.replace("def", "")
                s = s.replace("**", "** ")
                s = s[:-1]
                funcL.append(s)
                docflg = True
        tbL = zip(funcL, docstrL)
        titleS = self.parS.strip() + " (" + fuS + ")\n"
        titlerS = self.parS.strip() + " (" + fuS + ")\n\n"
        if titleS[0:2] == "--":
            ulS = " (" + fuS + ")\n"
            tlS = "(from file)"
            rlS = llS = " (" + fuS + ")\n\n"
        else:
            ulS = "\nTable " + fillS + ": " + titleS
            tlS = "\nTable " + fillS + ": (from file)"
            rlS = llS = "\n**Table " + fillS + "**: " + titlerS
        tblfmt = "rst"
        hdrvL = ["Function", "Docstring"]
        sys.stdout.flush()
        old_stdout = sys.stdout
        output = StringIO()
        output.write(
            tabulate.tabulate(
                tbL,
                tablefmt=tblfmt,
                headers=hdrvL,
                showindex=False,
                maxcolwidths=50,
                colglobalalign="left",
            )
        )
        outS = output.getvalue()
        sys.stdout = old_stdout
        sys.stdout.flush()
        # pthxS = str(Path(*Path(pthS).parts[-3:]))
        uS = ulS + "\n" + outS + "\n"
        tS = tlS + "\n" + outS + "\n"
        rS = rlS + "\n" + outS + "\n"
        lS = llS + "\n" + outS + "\n"

        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lS": lS,
            "lD": self.lD,
            "rivL": self.rivL,
            "rivtD": self.rivtD,
        }
        # endregion

    def FUNCTION(self):
        """evalutate function and assign value to var

           | FUNCTION | func(), assign var | title

        Returns:
            uS, r2S, rS, fD, lD, rivtD, rivL
        """
        # region
        functL = self.fileS.split(",")
        funcS = functL[0].strip()
        varS = functL[1].strip()
        newvarS = functL[2].strip()
        typeS = functL[3].strip()
        parL = self.parS.split(",")
        refS = parL[0].strip()
        self.enumI = int(self.lD["equI"])
        self.enumI += 1
        self.lD["equI"] = self.enumI
        self.enumS = str(self.enumI)
        cmdS = f"{funcS}(**{varS})"
        newvarS = eval(cmdS, globals(), self.rivtD)
        eq1S = textwrap.indent(
            "function: "
            + funcS
            + " | args: "
            + self.lD["argsname"]
            + " | "
            + self.lD["unit_note"],
            "      ",
        )

        eqxS = textwrap.indent(
            "function: "
            + funcS
            + " | args: "
            + self.lD["argsname"]
            + " | "
            + self.lD["unit_note"],
            chr(9474) + "    ",
        )

        toptS = chr(9484) + "  Eq-" + self.enumS + " | " + refS + "\n"
        erS = "\n\n**Eq. " + self.enumS + ":**  " + refS + "\n"
        # string return
        if typeS == "str":
            varwS = textwrap.indent(newvarS, "           ")
            eqrS = (
                erS
                + "\n.. code-block:: text \n\n"
                + eq1S
                + "\n           "
                + varwS
                + "\n\n"
            )
            eqtS = (
                toptS
                + chr(9474)
                + "\n"
                + eqxS
                + "\n"
                + chr(9492)
                + "\n\n"
                + newvarS
                + "\n\n"
            )
        else:
            pass
        uS = tS = eqtS
        rS = "\n" + eqrS + "\n\n"
        lS = ""
        self.mD = {
            "uS": uS,
            "rS": rS,
            "tS": tS,
            "lS": lS,
            "lD": self.lD,
            "fD": self.fD,
            "rivtD": self.rivtD,
            "rivL": self.rivL,
        }
        return self.mD, self.vardescD
        # endregion

    def wrap_pad(self, sentences, width=20):
        # Step 1: Wrap all sentences into lists of lines
        wrapped_data = [textwrap.wrap(s, width=width) for s in sentences]

        # Step 2: Identify the maximum number of lines
        max_height = max(len(lines) for lines in wrapped_data)

        # Step 3: Pad shorter sentences with empty lines to match max_height
        padded_data = []
        for lines in wrapped_data:
            # Create a copy and add empty strings until length matches max_height
            padded = lines + ["-"] * (max_height - len(lines))
            padded_data.append(padded)

        return padded_data

    def get_image_time(self, file_path):
        try:
            with Image.open(file_path) as img:
                # Retrieve EXIF data structure from Pillow
                exif_data = img.getexif()
                # Dictionary mapping numeric tags to human-readable strings
                if exif_data is not None:
                    exif_dict = {
                        exif_data.get(tag, tag): val
                        for tag, val in exif_data.items()
                    }
                    # Check standard EXIF timestamp priority tags
                    date_tags = [
                        "DateTimeOriginal",
                        "DateTimeDigitized",
                        "DateTime",
                    ]
                    tag = date_tags[0]
                    if exif_dict is not None and exif_dict != {}:
                        # print(exif_dict)
                        if tag in exif_dict and exif_dict[tag]:
                            # EXIF dates are typically formatted as 'YYYY:MM:DD HH:MM:SS'
                            raw_date = str(exif_dict[tag]).strip()
                            try:
                                return datetime.strptime(
                                    raw_date, "%Y:%m:%d %H:%M:%S"
                                )
                            except ValueError:
                                return "no time"
                    else:
                        pass
            # Check secondary PNG textual chunks or metadata if getexif fails
            if hasattr(img, "info") and img.info != {}:
                # PNG files often save timestamp info under 'date:create' or 'Creation Time'
                png_tags = ["date:create", "Creation Time", "creation_time"]
                for tag in png_tags:
                    # print(img.info)
                    if tag in img.info:
                        raw_date = img.info[tag].strip()
                        # Common format variations for PNG text chunks
                        for fmt in (
                            "%Y-%m-%dT%H:%M:%S%z",
                            "%Y:%m:%d %H:%M:%S",
                            "%Y-%m-%d %H:%M:%S",
                        ):
                            try:
                                return datetime.strptime(
                                    raw_date[:19], "%Y-%m-%dT%H:%M:%S"
                                )
                            except ValueError:
                                return "no time"
            else:
                return "no time"

        except Exception as e:
            print(f"cmd: Could not read metadata for {file_path}: {e}")
            return "no time"
