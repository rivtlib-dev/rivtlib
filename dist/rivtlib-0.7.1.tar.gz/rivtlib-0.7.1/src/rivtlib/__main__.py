"""rivtlib

library for processing *rivt files*
"""
