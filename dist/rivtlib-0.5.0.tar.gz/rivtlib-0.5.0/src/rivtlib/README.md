This is the repo for the *rivt* project and rivtlib package.
