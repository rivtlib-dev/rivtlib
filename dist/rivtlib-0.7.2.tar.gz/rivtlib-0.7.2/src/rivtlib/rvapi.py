#! python
"""
rivt API

usage:
    import rivtlib.rvapi as rv

API functions:
    rv.R(rS) - (Run) Execute shell scripts
    rv.I(rS) - (Insert) Insert static text, math, images and tables
    rv.V(rS) - (Values) Evaluate values and equations
    rv.T(rS) - (Tools) Execute Python scripts
    rv.D(rS) - (Docs) Publish formatted doc file
    rv.S(rS) - (Skip) Skip processing of section
    rv.X(rS) - (Exit) Exit processing of rivt file

where the argument rS is a triple quoted utf-8 string (rivt string)

Settings:
    rv_authD (dict): author information
    rv_localB (bool): True - reads and writes to local directory

Globals:
    utfS (str): utf doc string
    rstS (str): rstpdf doc string
    xstS (str): texpdf doc string
    lablD (dict): formatting parameters
    foldD (dict): folder and file paths
    rivD (dict): calculated values

Last letter of var name indicates type:
    A => array
    B => boolean
    C => class instance
    D => dictionary
    F => float
    I => integer
    L => list
    N => file name (string)
    O => object
    P => path
    S => string
    T => path + file name
"""

import fnmatch
import logging
import os
import sys
import warnings
from importlib.metadata import version
from pathlib import Path

import __main__
from rivtlib import rvdoc, rvparse

# region - rivt file name and paths
# set metadata variables
rivtP = Path(os.getcwd())
reptP = Path(os.path.dirname(rivtP))
rivtT = Path(__main__.__file__)
rivtN = (rivtT.name).strip()
modnameS = os.path.splitext(os.path.basename(__main__.__file__))[0]
pypathS = os.path.dirname(sys.executable)
rivtpkgP = os.path.join(pypathS, "Lib", "site-packages", "rivt")

if fnmatch.fnmatch(rivtN, "rv[A-Z0-9][0-9][0-9]-*.py"):
    pass
else:
    print(f"""The rivt file name provided was {rivtN}""")
    print("""The file name must match  rvDss-anyname.py""")
    print("""where D is a capital alpha-numeric division label""")
    print("""and ss is a two-digit subdivision integer""")
    sys.exit()
# endregion

# set rv_localB
rv_localB = False
with open(rivtT, "r") as f1:  # noqa: F405
    rivtL = f1.readlines()
for lnS in rivtL:
    if lnS[0] == "#":
        if "rv_localB" and "True" in lnS:
            rv_localB = True
# print(f"\n== {rv_localB=} ==")

# region - file names and paths
rbaseS = rivtN.split(".")[0]
rivtpN = rivtN.replace("rv", "rv-")
docnumS = rbaseS[0:6]
bakN = rbaseS + ".bak"
apilogN = docnumS + "api.txt"
errlogN = docnumS + "log.txt"
publicP = Path(rivtP, "public")
srcP = Path(rivtP, "src")
storeP = Path(rivtP, "store")
pubP = Path(rivtP, "publish")
logsP = Path(storeP, "logs")
# endregion

if rv_localB:
    errlogT = Path(rivtP, errlogN)
    apilogT = Path(rivtP, apilogN)
    bakT = Path(rivtP, bakN)
    rivtT = Path(rivtP, rivtN)
else:
    errlogT = Path(logsP, errlogN)
    apilogT = Path(logsP, apilogN)
    bakT = Path(logsP, bakN)
    rivtT = Path(rivtP, rivtN)

try:
    package_version = version("rivtlib")
    verS = f"rivtlib version: {package_version}"
except Exception as e:
    verS = f"rivtlib version not available: {e}"

# region - logs
warnings.filterwarnings("ignore")
try:
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)-8s  " + modnameS + "   %(levelname)-8s %(message)s",
        datefmt="%m-%d %H:%M",
        filename=errlogT,
        filemode="w",
    )
except Exception:
    pass
logging.info("Doc start")
logging.info(verS)
# write backup file
with open(rivtT, "r") as f2:  # noqa: F405
    rivtS = f2.read()
try:
    with open(bakT, "w") as f3:  # noqa: F405
        f3.write(rivtS)
    logging.info(f"""rivt backup : {bakT}""")  # noqa: F405
except Exception:
    pass
# api log
with open(apilogT, "w") as f4:
    f4.write("API log: " + rivtN + "\n")
    f4.write("---------------------------------------\n")
# end region

# region - dictionaries
rivD = {
    "rv_metaD": {
        "authors": " - ",
        "version": " - ",
        "email": " - ",
        "repo": " - ",
        "license": " - ",
        "fork1": [" - "],
        "fork2": [" - "],
    },
}
rv_metaD = {}  # metadata
foldD = {  # folders
    "rvlocalB": rv_localB,
    "pthS": " ",
    "srcnS": " ",
    "rivtN": rivtN,  # file name
    "rivtT": rivtT,  # full path name
    "rbaseS": rbaseS,  # file base name
    "rivtP": Path(os.getcwd()),
    "reptfoldN": os.path.dirname(rivtP),
    "docP": Path(rivtP, "rivDocs"),
    "pdfN": rbaseS + ".pdf",
    "readmeT": Path(rivtP, "README.txt"),
    "rivtpubP": Path(rivtP, "publish"),
    "rivtpub_P": Path(rivtP),
    "publicT": Path(rivtP, "public", rivtpN),
    "public_T": Path(rivtP, rivtpN),
    "srcP": srcP,
    "storeP": storeP,
    "valP": Path(srcP, "values"),
    "toolP": Path(srcP, "tools"),
    "styleP": Path(srcP, "styles"),
    "tempP": Path(srcP, "temp"),
    "val_P": rivtP,
    "style_P": rivtP,
    "tool_P": rivtP,
    "temp_P": rivtP,
    "errlogT": errlogT,
    "apilogT": apilogT,
    "bakT": bakT,
}
lablD = {  # dictionary of labels
    "rvtypeS": "",  # section type r,i,v,t,d
    "docnumS": rbaseS[0:6],  # doc number
    "divS": rbaseS[2:3],  # div number
    "sdivS": rbaseS[3:5],  # subdiv
    "docnameS": rbaseS[6:].replace("-", " "),  # document name
    "replablS": reptP.name[5:],
    "valprfx": rbaseS[0:6].replace("rv", "v"),
    "sectS": "",  # section title
    "secnumI": 0,  # section number
    "equI": 1,  # equation number
    "tableI": 1,  # table number
    "figI": 1,  # figure number
    "pageI": 1,  # starting page number
    "noteL": [0],  # endnote counter
    "descS": "ref",  # value description
    "deciI": 2,  # decimals
    "headrS": "",  # header string
    "footrS": "",  # footer string
    "aliaS": "rvsource",  # folder alias
    "unitS": "M,M",  # units
    "valexpS": "",  # list of values for export
    "publicB": False,  # public section
    "showB": True,  # print section to doc
    "mergeB": False,
    "apiB": True,
    "tocB": False,  # table of contents
    "subB": False,  # sub values in equations
    "colorL": ["red", "blue", "yellow", "green", "gray"],  # pallete
    "colorS": "none",  # topic background color
    "widthI": 80,  # print width
}
# endregion

# initialize doc strings
dutfS = ""
dr2pS = ""
drstS = ""
dhtmS = ""
cmdS = ""


def cmdhelp():
    """command line help"""

    print()
    print("Run rivt file on command line with:                     ")
    print()
    print("     python rvDss-filename.py                           ")
    print()
    print("Where D is a capital alpha-numeric division label       ")
    print("and ss is a two digit subdivision integer.              ")
    print("See User Manual at https://rivt.info for details        ")
    sys.exit()


def doc_parse(sS, tS, tagL, cmdL):
    """section string to doc string
    Args:
        sS (str): rivt section
        tS (str): section type (R,I,V,T,W,S)
    Calls:
        Section (class), section (method)
    Returns:
        sutfS (str): utf output
        srsrS (str): rst2pdf output
        srstS (str): reSt output
    """
    global dutfS, dr2pS, drstS, dhtmS, foldD, lablD, rivD
    sL = sS.split("\n")
    secC = rvparse.Section(tS, sL, foldD, lablD, rivD)
    sutfS, srsrS, srstS, foldD, lablD, rivD = secC.content(tagL, cmdL)
    # accumulate doc strings
    dutfS += sutfS
    dr2pS += srsrS
    drstS += srstS

    return dutfS, dr2pS, drstS


def R(rS):
    """Run shell command
    Args:
        rS (str): rivt section string
    """
    global dutfS, dr2pS, drstS, dhtmS, foldD, lablD, rivD
    cmdL = ["WIN", "OSX", "LINUX"]
    tagL = []
    dutfS, dr2pS, drstS = doc_parse(rS, "R", tagL, cmdL)


def I(rS):  # noqa: E743
    """Insert static source
    Args:
        rS (str): rivt section string
    """
    global dutfS, dr2pS, drstS, dhtmS, foldD, lablD, rivD
    cmdL = [
        "IMAGE",
        "IMAGE2",
        "FIGURE",
        "FIGURE2",
        "TABLE",
        "TEXT",
    ]
    tagL = [
        "#]",
        "C]",
        "R]",
        "E]",
        "I]",
        "T]",
        "G]",
        "S]",
        "D]",
        "U]",
        "A]",
        "L]",
        "-----",
        "=====",
    ]
    tagbL = [
        "[INDENT]]",
        "[ITALIC]]",
        "[ENDNOTES]]",
        "[PYTHON]]",
        "[HTML]]",
        "[RST]]",
        "[LATEX]]",
        "[TEXT]]",
        "[TOPIC]]",
        "[END]]",
    ]
    tagL = tagL + tagbL
    dutfS, dr2pS, drstS = doc_parse(rS, "I", tagL, cmdL)


def V(rS):
    """Values calculate
    Args:
        rS (str): rivt section string
    """
    global dutfS, dr2pS, drstS, dhtmS, foldD, lablD, rivD
    cmdL = [
        "IMAGE",
        "IMAGE2",
        "FIGURE",
        "FIGURE2",
        "TABLE",
        "VALUES",
        "PYTHON",
        ":=",
        "<=",
    ]
    tagL = [
        "#]",
        "C]",
        "R]",
        "E]",
        "I]",
        "T]",
        "G]",
        "S]",
        "D]",
        "U]",
        "-----",
        "=====",
    ]
    tagbL = [
        "[INDENT]]",
        "[ITALIC]]",
        "[ENDNOTES]]",
        "[PYTHON]]",
        "[HTML]]",
        "[RST]]",
        "[LATEX]]",
        "[TEXT]]",
        "[TOPIC]]",
        "[END]]",
    ]
    tagL = tagL + tagbL
    dutfS, dr2pS, drstS = doc_parse(rS, "V", tagL, cmdL)


def T(rS):
    """Python and Markup Tools
    Args:
        rS (str): rivt section string
    """
    global dutfS, dr2pS, drstS, dhtmS, foldD, lablD, rivD
    cmdL = ["| PYTHON |", "LATEX", "HTML", "RST"]
    tagL = ["[[PYTHON]]", "[[LATEX]]", "[[HTML]]", "[[RST]]"]
    blkB = False
    blkS = ""
    lL = rS.split("\n")
    for lS in lL:
        if blkB:  # tag flag
            if "[[END]]" in lS:
                blkB = False
                exec(blkS, globals(), rivD)
                blkS = ""
                continue
            blkS += lS.strip()
            continue
        for subS in tagL:  # tags
            if subS in lS:
                blkB = True
                continue
        for subS in cmdL:
            pass
    # print("eeeeeee", rivD["rv_metaD"])


def D(rS):
    """Publish Doc files

    Writes docs as .txt, .pdf (reportLab or tex) and .html

    Args:
        sS (str): section string
    """
    global dutfS, dr2pS, drstS, dhtmS, foldD, lablD, rivD
    # config = ConfigParser()
    # config.read(Path(reptfoldP, "rivt-doc.ini"))
    # headS = config.get("report", "title")
    # footS = config.get("utf", "foot1")
    cmdL = ["PUBLISH", "ATTACH"]
    tagL = ["[LAYOUT]]"]
    wrtdoc = rvdoc.Cmdp(rS, foldD, lablD, cmdL, tagL, dutfS, dr2pS, drstS, rivD)
    mssgS = wrtdoc.cmdx()
    print("\n" + f"{mssgS}")
    sys.exit()


def S(rS):
    """skip section string - not processed
    Args:
        rS (str): rivt section string
    """
    shL = rS.split("\n")
    print("\n[" + shL[0].strip() + "] : section skipped " + "\n")


def X(rS):
    """exit rivtlib processing
    Args:
        rS (str): rivt section string
    """
    shL = rS.split("\n")
    logging.info("exit rivt file at: " + shL[0])
    print("\n[" + shL[0].strip() + "] : rivtlib exit " + "\n")
    sys.exit()
