#! python
"""
rivt API

usage:
    import rivtlib.api as rv

API functions:
    rv.R(sS) - (Run) Execute shell scripts
    rv.I(sS) - (Insert) Insert static text, math, images and tables
    rv.V(sS) - (Values) Evaluate values and equations
    rv.T(sS) - (Tools) Execute Python scripts
    rv.D(sS) - (Docs) Write formatted document files
    rv.S(sS) - (Skip) Skip processing of that section
    rv.Q(sS) - (Quit) Exit processing of rivt file

where sS is a section string - a triple quoted utf-8 string with a parameter
header on the first line

Globals:
    utfS (str): utf doc string
    rstS (str): rstpdf doc string
    xstS (str): texpdf doc string
    labelD (dict): formatting labels
    folderD (dict): folder and file paths
    rivtD (dict): calculated values

Last letter of var name indicates type:
    A => array
    B => boolean
    C => class instance
    D => dictionary
    F => float
    I => integer
    L => list
    N => file name
    O => object
    P => path
    S => string
    T => total path (includes file)
"""

import fnmatch
import logging
import os
import sys
import warnings
from datetime import datetime
from pathlib import Path

import __main__
from rivtlib import rvparse
from rvunits import *  # noqa: F403

from . import rvdoc

rivtP = Path(os.getcwd())
projP = Path(os.path.dirname(rivtP))
modnameS = __name__.split(".")[1]

# region - parse file nane
if __name__ == "rivtlib.rvparam":
    rivtT = Path(__main__.__file__)
    rivtN = rivtT.name
    patternS = "r[0-9][0-9][0-9]0-9]-*.py"
    if fnmatch.fnmatch(rivtN, patternS):
        rivtfP = Path(rivtP, rivtN)
else:
    print(f"""The rivt file name is - {rivtN} -. The file name must""")
    print("""match "rddss-anyname.py", where dd and ss are two-digit integers""")
    sys.exit()
# print(f"{rivtT=}")
# print(f"{__name__=}")
# print(f"{modnameS=}")

# input files
prfxS = rivtN[0:6]
rnumS = rivtN[2:6]
dnumS = prfxS[2:4]
# endregion


# region - file paths
# input files
pthS = " "
rbaseS = rivtN.split(".")[0]
divnumS = "d" + dnumS + "-"
rstnS = rbaseS + ".rst"
txtnS = rbaseS + ".txt"
pdfnS = rbaseS + ".pdf"
htmnS = rbaseS + ".html"
bakN = rbaseS + ".bak"
docP = Path(projP, "rivtdocs")
srcP = Path(projP, "sources")
styleP = Path(projP, "styles")
titleS = rivtN.split("-")[1]

# output files
bakT = Path(rivtP, bakN)
rbakT = Path(rivtP, rbaseS + ".bak")
pypathS = os.path.dirname(sys.executable)
rivtpkgP = os.path.join(pypathS, "Lib", "site-packages", "rivt")
styleP = Path(projP, "style")
reportP = Path(projP, "rivtdocs", "report")
ossP = Path(projP / "rivtos")
valN = prfxS.replace("rv", "v")

# read/write
valP = Path(srcP, "v" + dnumS)

# print(f"{projP=}")
# print(f"{rivtP=}")
# print(f"{insP=}")
# print(f"{valsP=}")
# endregion

# region - folders dict
folderD = {
    "pthS": " ",
    "rivtT": rivtT,  # full path and name
    "rivtN": rivtT.name,  # file name
    "baseS": rbaseS,  # file base name
    "rivtP": Path(os.getcwd()),
    "projP": Path(os.path.dirname(rivtP)),
    "docP": Path(projP, "rivtdocs"),
    "bakT": Path(rivtP, bakN),
    "errlogT": Path(rivtP, "error.log"),
    "pdfN": rbaseS + ".pdf",
    "readmeT": Path(projP, "README.txt"),
    "reportP": Path(projP, "rivtdocs", "report"),
    "styleP": Path(projP, "rivtdocs", "style"),
    "srcP": srcP,
    "rstpN": rstnS,
    "pdfpN": pdfnS,
    "runP": Path(srcP, "r" + dnumS),
    "insP": Path(srcP, "i" + dnumS),
    "valP": Path(srcP, "v" + dnumS),
    "tooP": Path(srcP, "t" + dnumS),
    "valN": valN,
    "srcnS": "",
}
# endregion

# region - labels dict
labelD = {
    "divnumS": divnumS,  # div number
    "docnumS": prfxS,  # doc number
    "titleS": titleS,  # document title
    "sectS": "",  # section title
    "secnumI": 0,  # section number
    "widthI": 80,  # print width
    "equI": 1,  # equation number
    "tableI": 1,  # table number
    "figI": 1,  # figure number
    "pageI": 1,  # starting page number
    "noteL": [0],  # footnote counter
    "footL": [1],  # foot counter
    "descS": "2",  # description or decimal places
    "headrS": "",  # header string
    "footrS": "",  # footer string
    "tocB": False,  # table of contents
    "docstrB": False,  # print doc strings
    "subB": False,  # sub values in equations
    "rvtosB": False,  # open-source rivt flag
    "valexpS": "",  # list of values for export
    "unitS": "M,M",  # units
    "colorL": ["red", "blue", "yellow", "green", "gray"],  # pallete
    "colorS": "none",  # background color
}
# endregion

# region - values dict
rivtD = {}  # shared calculated values
# endregion

# region - logging and backup
errlogT = Path(projP, "temp", prfxS + "-log.txt")
modnameS = os.path.splitext(os.path.basename(__main__.__file__))[0]
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)-8s  " + modnameS + "   %(levelname)-8s %(message)s",
    datefmt="%m-%d %H:%M",
    filename=errlogT,
    filemode="w",
)
warnings.filterwarnings("ignore")

logging.info(f"""rivt file : {folderD["rivtN"]}""")
logging.info(f"""rivt path : {folderD["rivtP"]}""")


with open(folderD["rivtT"], "r") as f2:  # noqa: F405
    rivtS = f2.read()
with open(folderD["bakT"], "w") as f3:  # noqa: F405
    f3.write(rivtS)
logging.info(f"""rivt backup : {folderD["bakT"]}""")  # noqa: F405
# endregion


def doc_hdr():
    """generate document header

    Returns:
        str: doc string header
    """
    # init file - (headings and doc overrides)

    dutfS = ""
    drs2S = ""
    drstS = ""
    # config = ConfigParser()
    # config.read(Path(projP, "rivt-doc.ini"))
    # headS = config.get("report", "title")
    # footS = config.get("utf", "foot1")
    titleL = rivtN.split("-")  # subdivision title
    titleS = titleL[1].split(".")[0]
    dnumS = titleL[0].split("r")[1]
    headS = dnumS + "   " + titleS
    timeS = datetime.now().strftime("%Y-%m-%d | %I:%M%p")
    borderS = "=" * 80
    dutfS = "\n\n" + timeS + "   " + headS + "\n" + borderS + "\n"
    print(dutfS)  # STDOOUT doc heading
    dutfS = dutfS  # accumulate doc strings
    drs2S = dutfS
    drstS = dutfS

    return dutfS, drs2S, drstS


def doc_parse(sS, tS, tagL, cmdL):
    """section string to doc string
    Args:
        sS (str): rivt section
        tS (str): section type (R,I,V,T,W,S)
    Calls:
        Section (class), section (method)
    Returns:
        sutfS (str): utf output
        srs2S (str): rst2pdf output
        srstS (str): reSt output
    """
    global dutfS, drs2S, drstS, folderD, labelD, rivtD
    sL = sS.split("\n")
    secC = rvparse.Section(tS, sL, folderD, labelD, rivtD)
    sutfS, srs2S, srstS, folderD, labelD, rivtD, rivtL = secC.section(tagL, cmdL)
    # accumulate doc strings
    dutfS += sutfS
    drs2S += srs2S
    drstS += srstS

    return dutfS, drs2S, drstS, rivtL


def R(sS):
    """Run shell command
    Args:
        sS (str): section string
    """
    global dutfS, drs2S, drstS, folderD, labelD, rivtD
    cmdL = ["WIN", "OSX", "LINUX"]
    tagL = []
    dutfS, drs2S, drstS, rivtL = doc_parse(sS, "R", tagL, cmdL)


def I(sS):  # noqa: E743
    """Insert static source
    Args:
        sS (str): section string
    """
    global dutfS, drs2S, drstS, folderD, labelD, rivtD
    cmdL = ["IMG", "IMG2", "TABLE", "TEXT"]
    tag1L = ["#]", "C]", "D]", "E]", "F]", "S]", "L]", "T]", "H]", "P]", "U]"]
    tag2L = ["B]]", "C]]", "I]]", "L]]", "X]]"]
    tagL = tag1L + tag2L
    dutfS, drs2S, drstS, rivtL = doc_parse(sS, "I", tagL, cmdL)


def V(sS):
    """Values calculate
    Args:
        sS (str): section string
    """
    global dutfS, drs2S, drstS, folderD, labelD, rivtD
    cmdL = ["IMG", "IMG2", "VALUE"]
    tagL = ["E]", "F]", "S]", "Y]", "T]", "H]", "P]", "[V]]", ":="]
    dutfS, drs2S, drstS, rivtL = doc_parse(sS, "V", tagL, cmdL)

    # write values file
    fileS = folderD["valN"] + "-" + str(labelD["secnumI"]) + ".csv"
    fileP = Path(folderD["valP"], fileS)
    with open(fileP, "w") as file1:
        file1.write("\n".join(rivtL))


def T(sS):
    """Tools in Python
    Args:
        sS (str): section string
    """
    global dutfS, drs2S, drstS, folderD, labelD, rivtD
    cmdL = ["Python"]
    tagL = []
    dutfS, drs2S, drstS, rivtL = doc_parse(sS, "T", tagL, cmdL)


def P(sS):
    """Write doc files

    Writes docs as .txt, .pdf (from reportab or tex) and .html

    Args:
        sS (str): section string
    """
    global dutfS, drs2S, drstS, folderD, labelD, rivtD
    print("9999999999999999999999999999999999999")
    print(drs2S)
    cmdL = ["DOC", "ATTACH"]
    wrtdoc = rvdoc.Cmdp(folderD, labelD, sS, cmdL, drs2S)
    mssgS = wrtdoc.cmdpx()
    print("\n" + f"{mssgS}")
    sys.exit()


def S(sS):
    """skip section string - not processed
    Args:
        sS (str): section string
    """
    shL = sS.split("\n")
    print("\n[" + shL[0].strip() + "] : section skipped " + "\n")


# begin doc generation - returns doc as txt, rst2 and rst string
dutfS, drs2S, drstS = doc_hdr()
